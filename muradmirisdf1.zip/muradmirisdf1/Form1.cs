﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace muradmirisdf1
{
    // 1. DİZAYNER ÜÇÜN TƏLƏB: İlk sinif MÜTLƏQ Form1 olmalıdır!
    public partial class Form1 : Form
    {
        private EmployeeServiceBase service = new EmployeeService();

        public Form1()
        {
            InitializeComponent();

            // Proqram açılan kimi avtomatik '240' kodlu test işçisi əlavə olunur
            if (service.FindEmployee("240") == null)
            {
                service.AddEmployee(new Employee("240", "Murad", "Miri", 19));
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        // Mərkəzi idarəetmə metodu (Hansı Tab aktivdirsə onu yerinə yetirir)
        private void ExecuteAction()
        {
            // 0-cı Tab: İŞÇİ ƏLAVƏ ET
            if (tabControl1.SelectedIndex == 0)
            {
                string code = textBox1.Text.Trim();
                string firstName = textBox2.Text.Trim();
                string lastName = textBox3.Text.Trim();

                if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
                {
                    MessageBox.Show("Bütün xanaları doldurun!", "Xəbərdarlıq", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(textBox4.Text, out int age) || age <= 0)
                {
                    MessageBox.Show("Yaş düzgün daxil edilməyib!", "Xəta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Employee newEmp = new Employee(code, firstName, lastName, age);

                if (service.AddEmployee(newEmp))
                {
                    MessageBox.Show("İşçi uğurla əlavə olundu!", "Uğur", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                }
                else
                {
                    MessageBox.Show("Bu koda malik işçi artıq mövcuddur!", "Xəbərdarlıq", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            // 1-ci Tab: ÖDƏNİŞ YAZ
            else if (tabControl1.SelectedIndex == 1)
            {
                string code = textBox5.Text.Trim();
                string title = textBox6.Text.Trim();

                if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(title))
                {
                    MessageBox.Show("İşçi kodu və ödəniş adı boş ola bilməz!", "Xəbərdarlıq", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!double.TryParse(textBox7.Text, out double amount) || amount <= 0)
                {
                    MessageBox.Show("Məbləğ 0-dan böyük olmalıdır!", "Xəta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Employee emp = service.FindEmployee(code);
                if (emp == null)
                {
                    MessageBox.Show($"'{code}' kodlu işçi tapılmadı! Əvvəlcə 'İşçi əlavə et' bölməsindən bu kodu qeydiyyatdan keçirin.", "Xəta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (service.AddPayment(code, title, amount))
                {
                    MessageBox.Show("Ödəniş uğurla əlavə olundu!", "Uğur", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox5.Clear();
                    textBox6.Clear();
                    textBox7.Clear();

                    listBox1.Items.Clear();
                    foreach (var p in emp.Payments)
                    {
                        listBox1.Items.Add(p.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Ödəniş əlavə edilə bilmədi!", "Xəta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e) { ExecuteAction(); }
        private void button2_Click_1(object sender, EventArgs e) { ExecuteAction(); }
        private void button2_Click(object sender, EventArgs e) { ExecuteAction(); }

        // 3. STATİSTİKA / AXTARIŞ (TabPage 3)
        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            string searchCode = textBox8.Text.Trim();

            if (string.IsNullOrEmpty(searchCode))
            {
                listBox2.Items.Clear();
                return;
            }

            Employee emp = service.FindEmployee(searchCode);
            listBox2.Items.Clear();

            if (emp != null)
            {
                listBox2.Items.Add($"Kod: {emp.Code}");
                listBox2.Items.Add($"Ad, Soyad: {emp.FirstName} {emp.LastName}");
                listBox2.Items.Add($"Yaş: {emp.Age}");
                listBox2.Items.Add("--- Ödənişlər ---");

                if (emp.Payments.Count > 0)
                {
                    foreach (var p in emp.Payments)
                    {
                        listBox2.Items.Add(p.ToString());
                    }
                }
                else
                {
                    listBox2.Items.Add("Heç bir ödəniş yoxdur.");
                }
            }
            else
            {
                listBox2.Items.Add("Belə kodda işçi tapılmadı.");
            }
        }

        // Digər boş eventlər
        private void label2_Click(object sender, EventArgs e) { }
        private void tabPage1_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void textBox6_TextChanged(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void textBox7_TextChanged(object sender, EventArgs e) { }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void tabPage2_Click(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e) { }
        private void tabPage3_Click(object sender, EventArgs e) { }
    }

    // 2. DİGƏR SİNİFLƏR İNDİ FORM1-DƏN SONRA GƏLİR
    public class Payment
    {
        public string Title { get; set; }
        public double Amount { get; set; }

        public Payment(string title, double amount)
        {
            Title = title;
            Amount = amount;
        }

        public override string ToString()
        {
            return $"{Title} — {Amount} AZN";
        }
    }

    public class Employee
    {
        public string Code { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public List<Payment> Payments { get; set; }

        public Employee(string code, string firstName, string lastName, int age)
        {
            Code = code;
            FirstName = firstName;
            LastName = lastName;
            Age = age;
            Payments = new List<Payment>();
        }

        public override string ToString()
        {
            return $"{Code} | {FirstName} {LastName}";
        }
    }

    public abstract class EmployeeServiceBase
    {
        public abstract bool AddEmployee(Employee employee);
        public abstract Employee FindEmployee(string code);
        public abstract bool AddPayment(string employeeCode, string title, double amount);
        public abstract List<Payment> GetEmployeePayments(string employeeCode);
        public abstract List<Employee> GetAllEmployees();
    }

    public class EmployeeService : EmployeeServiceBase
    {
        public static List<Employee> Employees = new List<Employee>();

        public override bool AddEmployee(Employee employee)
        {
            if (Employees.Any(e => e.Code == employee.Code))
            {
                return false;
            }
            Employees.Add(employee);
            return true;
        }

        public override Employee FindEmployee(string code)
        {
            return Employees.FirstOrDefault(e => e.Code == code);
        }

        public override bool AddPayment(string employeeCode, string title, double amount)
        {
            if (amount <= 0) return false;
            Employee emp = FindEmployee(employeeCode);
            if (emp == null) return false;

            emp.Payments.Add(new Payment(title, amount));
            return true;
        }

        public override List<Payment> GetEmployeePayments(string employeeCode)
        {
            Employee emp = FindEmployee(employeeCode);
            if (emp == null) return null;
            return emp.Payments;
        }

        public override List<Employee> GetAllEmployees()
        {
            return Employees;
        }
    }
}